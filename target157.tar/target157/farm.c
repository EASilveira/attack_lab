/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_458()
{
    return 2421721073U;
}

unsigned getval_279()
{
    return 2425378990U;
}

unsigned addval_124(unsigned x)
{
    return x + 3347663984U;
}

unsigned getval_454()
{
    return 406497033U;
}

unsigned getval_353()
{
    return 2428995912U;
}

unsigned getval_449()
{
    return 3284633928U;
}

unsigned getval_496()
{
    return 2425394264U;
}

unsigned getval_406()
{
    return 3284633932U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_419()
{
    return 2026099081U;
}

unsigned getval_489()
{
    return 3281112713U;
}

unsigned addval_151(unsigned x)
{
    return x + 3223375501U;
}

unsigned addval_285(unsigned x)
{
    return x + 2463009086U;
}

unsigned getval_309()
{
    return 3523265161U;
}

unsigned getval_123()
{
    return 3372794505U;
}

void setval_249(unsigned *p)
{
    *p = 1690485385U;
}

void setval_176(unsigned *p)
{
    *p = 3223376257U;
}

void setval_430(unsigned *p)
{
    *p = 3285096925U;
}

unsigned getval_450()
{
    return 2425471625U;
}

unsigned addval_301(unsigned x)
{
    return x + 2430634344U;
}

unsigned getval_314()
{
    return 3677933961U;
}

void setval_439(unsigned *p)
{
    *p = 3687108233U;
}

unsigned getval_447()
{
    return 3284306223U;
}

void setval_399(unsigned *p)
{
    *p = 2797850249U;
}

unsigned getval_443()
{
    return 3286272456U;
}

unsigned getval_108()
{
    return 3281179017U;
}

unsigned getval_239()
{
    return 2425409153U;
}

void setval_414(unsigned *p)
{
    *p = 2425409945U;
}

unsigned getval_178()
{
    return 2430634312U;
}

void setval_349(unsigned *p)
{
    *p = 3374891657U;
}

unsigned addval_263(unsigned x)
{
    return x + 3285289188U;
}

unsigned addval_251(unsigned x)
{
    return x + 2447411528U;
}

void setval_133(unsigned *p)
{
    *p = 3767093381U;
}

unsigned addval_271(unsigned x)
{
    return x + 3526935049U;
}

void setval_348(unsigned *p)
{
    *p = 3269495112U;
}

unsigned getval_119()
{
    return 3680555401U;
}

unsigned getval_495()
{
    return 3252717896U;
}

void setval_394(unsigned *p)
{
    *p = 3682910729U;
}

unsigned addval_207(unsigned x)
{
    return x + 3372797577U;
}

void setval_397(unsigned *p)
{
    *p = 3223376137U;
}

unsigned getval_315()
{
    return 3286272264U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
